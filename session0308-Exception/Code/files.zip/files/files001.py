file = open("c:\\files\\example.txt","w")
file.write("Hello dear friends.")
file.write("\nWhere are you people?")

file.close()
