# sets are unordered
'''numbers = {11, 22, 33, 44, 55}
print(numbers)
'''

# sets are unique
'''numbers = {11, 22, 33, 44, 22, 55, 11}
print(numbers)
'''

# sets are mutable
numbers = {11, 22, 33, 44, 55}
print(numbers)
numbers.add(66)
print(numbers)
numbers.remove(33)
print(numbers)
numbers.update({77, 88})
print(numbers)

numbers.discard(99)
print(numbers)

numbers.pop()
print(numbers)