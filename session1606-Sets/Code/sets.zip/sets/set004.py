# A frozen set is a set that cannot be modified.
fs1 = frozenset({1, 2, 3, 4})

#fs1.remove(3)
fs1.add(5)
print(fs1)