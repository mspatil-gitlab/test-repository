'''l1 = []
t1 = ()
s1 = {} # dictionary
print(type(l1))
print(type(t1))
print(type(s1))
'''
l1 = list()
t1 = tuple()
s1 = set()
print(type(l1))
print(type(t1))
print(type(s1))