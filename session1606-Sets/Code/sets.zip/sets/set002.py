set1 = {1, 2, 3}
set2 = {3, 4, 5}

# 1. union
'''result  = set1.union(set2)
print(result)
result = set1 | set2
print(result)
'''

# 2. intersection
'''result  = set1.intersection(set2)
print(result)
result = set1 & set2
print(result)
'''

# 3. difference
'''set1 = {1, 2, 3}
set2 = {3, 4, 5}

result  = set1.difference(set2)
print(result)
result = set1 - set2
print(result)
'''
# 4. Symmetric difference
'''set1 = {1, 2, 3}
set2 = {3, 4, 5}

result = set1.symmetric_difference(set2)
print(result)
result = set1 ^ set2
print(result)
'''
# 5. Set Methods

A = {1, 2, 3}
B = {1, 2, 3, 4}

print(A.issubset(B))
print(B.issubset(A))

print(A.issuperset(B))
print(B.issuperset(A))